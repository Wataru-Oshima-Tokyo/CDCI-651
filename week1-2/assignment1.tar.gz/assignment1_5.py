from functools import total_ordering
import networkx as nx
import matplotlib.pyplot as plt
import math
import numpy as np

# erdos_renyi graph generator
def _erdos_renyi_graph(n, p):
    # make a graph
    G = nx.Graph()
    # adding nodes according to n
    nodes =[]
    for a in range(n):
        nodes.append(a)
    G.add_nodes_from(nodes)
    #number of pairs
    # pairs = math.comb(n,2) # n*(n-1)/2
    # print(pairs)
    # adding edges
    edges =[]
    for i in range(n):
        degree = 0
        for j in range(i+1,n): # from the node itself +1 to the last node
            if np.random.rand() <p: # if the random number is bigger than input p then
                edges.append((i,j)) # make an edge between them
    aveDegree = 2*len(edges)/n #<k>
    # print("average of degree is:", aveDegree)
    G.add_edges_from(edges)
    #the size of giantcomponent
    Gcc = len(max(nx.connected_components(G), key=len))
    # print(Gcc)
    return G,Gcc,aveDegree

if __name__ == "__main__":
    n = 1000 # number of nodes
    numOfGraphs =10 # number of graphs
    _p = 0.002 # reasonable probability 
    x =[]
    y =[]
    k =[]
    c =[]
    for a in range(numOfGraphs):
        p = np.random.uniform(0,_p)
        G, Gcc, avgD = _erdos_renyi_graph(n,p)
        x.append(avgD)
        y.append(Gcc/n)
        if avgD >1:
            k.append("Supercritiacal regime")
        elif avgD <1:
            k.append("Subcritical regime")
        else:
            k.append("Crital point")
        if Gcc/n ==1:
            c.append(True)
        else:
            c.append(False)
    # print(x,y)
    plt.scatter(x,y)
    #obtain m (slope) and b(intercept) of linear regression line
    m, b = np.polyfit(x, y, 1)
    line = [m*_x +b for _x in x]
    #use red as color for regression line
    plt.plot(x, line, color='red')
    plt.xlabel('<k>')
    plt.ylabel('(size of giant comp)/number of vertices')
    #Showing the result for each graph
    for i in range(numOfGraphs):
        print("The graph ", end="")
        print(i+1)
        print(k[i])
        if c[i]:
            print("connected regime\n")
        else:
            print("not connected regime\n")
    plt.show()
    